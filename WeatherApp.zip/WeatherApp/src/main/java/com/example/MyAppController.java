package com.example;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.List;
import java.util.ArrayList;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class MyAppController {

    @FXML
    private Button button;

    @FXML
    private Label weatherOutput;

    @FXML
    private Label temperatureOutput;

    @FXML
    private Label cityName;

    @FXML
    private TextField cityInput;

    @FXML
    private ListView<String> suggestionsList;

    @FXML
    private ImageView weatherIcon;

    private static final String WEATHER_API_KEY = "ef4db51685a1652c988eb8eb41255cd4";
    private static final String LOCATIONIQ_API_KEY = "pk.34835cf31e5b2705186973571f2a1a10";
    private static final String LOCATIONIQ_API_URL = "https://us1.locationiq.com/v1/autocomplete.php?key=%s&q=%s&format=json";

    @FXML
    void buttonOnAction(ActionEvent event) {
        fetchWeather();
    }

    @FXML
    void onCityInputKeyReleased(KeyEvent event) {
        String input = cityInput.getText();
        if (input.length() > 2) {
            fetchCitySuggestions(input);
        } else {
            Platform.runLater(() -> suggestionsList.setVisible(false));
        }
    }

    @FXML
    void onSuggestionClicked(MouseEvent event) {
        String selectedCity = suggestionsList.getSelectionModel().getSelectedItem();
        if (selectedCity != null) {
            String mainCityName = extractMainCityName(selectedCity);
            cityInput.setText(mainCityName);
            suggestionsList.setVisible(false);
        }
    }

    private void fetchCitySuggestions(String query) {
        try {
            String encodedQuery = URLEncoder.encode(query, StandardCharsets.UTF_8.toString());
            String url = String.format(LOCATIONIQ_API_URL, LOCATIONIQ_API_KEY, encodedQuery);

            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder().uri(URI.create(url)).build();

            client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                  .thenApply(HttpResponse::body)
                  .thenAccept(response -> {
                      try {
                          JSONArray jsonArray = new JSONArray(response);
                          List<String> validSuggestions = new ArrayList<>();

                          for (int i = 0; i < jsonArray.length(); i++) {
                              String displayName = jsonArray.getJSONObject(i).getString("display_name");
                              String[] parts = displayName.split(",");
                              String mainCityName = parts[0].trim();
                              
                              if (isCityAvailableInWeatherAPI(mainCityName)) {
                                  validSuggestions.add(displayName);
                              }
                          }

                          Platform.runLater(() -> {
                              suggestionsList.getItems().setAll(validSuggestions);
                              suggestionsList.setVisible(!validSuggestions.isEmpty());
                          });
                      } catch (Exception e) {
                          Platform.runLater(() -> suggestionsList.setVisible(false));
                      }
                  })
                  .exceptionally(e -> {
                      Platform.runLater(() -> suggestionsList.setVisible(false));
                      return null;
                  });
        } catch (Exception e) {
            Platform.runLater(() -> suggestionsList.setVisible(false));
        }
    }

    private boolean isCityAvailableInWeatherAPI(String cityName) {
        try {
            String encodedCity = URLEncoder.encode(cityName, StandardCharsets.UTF_8.toString());
            String url = String.format(
                "https://api.openweathermap.org/data/2.5/weather?q=%s&appid=%s",
                encodedCity, WEATHER_API_KEY
            );

            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder().uri(URI.create(url)).build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            JSONObject json = new JSONObject(response.body());
            return json.has("main");
        } catch (Exception e) {
            return false;
        }
    }

    private String extractMainCityName(String fullCityName) {
        String[] parts = fullCityName.split(",");
        return parts[0].trim();
    }

    public void fetchWeather() {
        String city = cityInput.getText();
        if (city.isEmpty()) {
            Platform.runLater(() -> weatherOutput.setText("Please enter a city name."));
            return;
        }

        try {
            String encodedCity = URLEncoder.encode(city, StandardCharsets.UTF_8.toString());
            String url = String.format(
                "https://api.openweathermap.org/data/2.5/weather?q=%s&appid=%s&units=metric",
                encodedCity, WEATHER_API_KEY
            );

            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder().uri(URI.create(url)).build();

            client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                  .thenApply(HttpResponse::body)
                  .thenAccept(response -> {
                      System.out.println(response);
                      try {
                          JSONObject json = new JSONObject(response);
                          if (json.has("main") && json.has("weather")) {
                              double temp = json.getJSONObject("main").getDouble("temp");
                              int humidity = json.getJSONObject("main").getInt("humidity");
                              String description = json.getJSONArray("weather").getJSONObject(0).getString("description");
                              String iconCode = json.getJSONArray("weather").getJSONObject(0).getString("icon");
                              String iconUrl = String.format("https://openweathermap.org/img/wn/%s@2x.png", iconCode);
                              String cityNameWithCountry = json.getString("name") + ", " + json.getJSONObject("sys").getString("country");

                              Platform.runLater(() -> {
                                  cityName.setText(cityNameWithCountry);
                                  weatherIcon.setImage(new Image(iconUrl));
                                  temperatureOutput.setText(String.format("%.1f°C", temp));
                                  weatherOutput.setText(String.format("Weather: %s\nHumidity: %d%%", capitalize(description), humidity));
                              });
                          } else {
                              Platform.runLater(() -> weatherOutput.setText("City not found."));
                          }
                      } catch (Exception e) {
                          Platform.runLater(() -> weatherOutput.setText("Error parsing data."));
                      }
                  })
                  .exceptionally(e -> {
                      Platform.runLater(() -> weatherOutput.setText("Error fetching weather: " + e.getMessage()));
                      return null;
                  });
        } catch (Exception e) {
            Platform.runLater(() -> weatherOutput.setText("Error encoding city name."));
        }
    }

    private String capitalize(String text) {
        if (text == null || text.isEmpty()) return text;
        return Character.toUpperCase(text.charAt(0)) + text.substring(1);
    }
    
    

    @FXML
    public void initialize() {
        Platform.runLater(() -> {
            weatherOutput.setText("Enter a city and click 'Get Weather'.");
            Stage stage = (Stage) button.getScene().getWindow();
            stage.getScene().getStylesheets().add(getClass().getResource("/com/example/styles.css").toExternalForm());
            stage.setMinWidth(400);
            stage.setMinHeight(600);
        });
    }
}




